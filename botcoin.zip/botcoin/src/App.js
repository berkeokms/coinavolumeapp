import logo from './logo.svg';
import './App.css';
import React from 'react';

function Coin(props) {
  return(
      <tr>
        <td className="title">{props.title}</td>
        <td>{props.volume}</td>
        <td>{props.priceChangePercent}</td>
      </tr>
  );
}

function App() {
  const [coins, setCoins] = React.useState([]);

  
  React.useEffect(() => {

    const fetchData = async() => {
      await fetch('https://api.binance.com/api/v3/ticker/24hr')
      .then(response => response.json())
      .then(arr => arr.filter((coin) => {
          return coin.symbol.includes("USDT") && !coin.symbol.includes("DOWN");
      }))
      .then(coins => coins.sort(function(a, b) {
        var keyA = Number(a.volume),
          keyB = Number(b.volume);
        // Compare the 2 dates
        if (keyA < keyB) return 1;
        if (keyA > keyB) return -1;
        return 0;
      }))
      .then(data => setCoins(data));
    }

    const intervalId = setInterval(() => {
      fetchData();
     }, 5000);

     return () => clearInterval(intervalId); //This is important

  }, []);

  return (
    <div>
      <table>
        {coins.map((coin) => {
          return (
            <Coin key={coin.symbol} title={coin.symbol} volume={coin.volume} priceChangePercent={coin.priceChangePercent}/>
            );
        })}
      </table>
    </div>
  );
}

export default App;
